package br.com.tk.mcs.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

import br.com.tk.mcs.Database.PersistenceController;
import br.com.tk.mcs.Generic.TColor;
import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.R;

public class RegisterLaneActivity extends AppCompatActivity implements View.OnClickListener {

    private boolean update;
    private String m_ip;
    private Button btUpAdd;
    private EditText edtIP;
    private Spinner spName;
    private Spinner sentido;
    private List<String> list;
    private List<String> list2;
    private static final String IP = "IP";
    private PersistenceController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_lane);
        update = false;
        controller = new PersistenceController(this);

        edtIP   = (EditText) findViewById(R.id.edtIP);
        btUpAdd = (Button)findViewById(R.id.btUpAdd);
        btUpAdd.setOnClickListener(this);

        sentido= (Spinner) findViewById(R.id.spinner2);
        list2 = new ArrayList<String>();
        list2.add("P");
        list2.add("S");
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
         sentido.setAdapter(dataAdapter2);

        spName = (Spinner) findViewById(R.id.spinner);
        list = new ArrayList<String>();
        for(int i = 1; i < 30; i++) list.add(getString(R.string.manager_lane_name) + String.format(" %02d", i));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spName.setAdapter(dataAdapter);



        Bundle bundle = getIntent().getExtras();
        if(bundle != null) {
            if ( bundle.containsKey(IP) ) {
                m_ip = bundle.getString(IP);
                edtIP.setText(m_ip);
                int pos = dataAdapter.getPosition(controller.getLaneNameByIP(m_ip));
                spName.setSelection( pos );
                update = true;
            }
        }
    }

    @Override
    public void onClick(View view) {
        if ( !edtIP.getText().toString().isEmpty() && !spName.getSelectedItem().toString().isEmpty() ) {
            if ( !update ) {
                if ( !controller.insertLane(spName.getSelectedItem().toString(), edtIP.getText().toString(),sentido.getSelectedItem().toString() ) ) {
                    Toast.makeText(getApplicationContext(), getString(R.string.register_msg_error), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.register_msg_add), Toast.LENGTH_SHORT).show();
                    this.finish();
                }
            } else {
                if ( !controller.updateLane(m_ip, edtIP.getText().toString(), spName.getSelectedItem().toString() ) ) {
                    Toast.makeText(getApplicationContext(), getString(R.string.register_msg_error), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.register_msg_up), Toast.LENGTH_SHORT).show();
                    this.finish();
                }
            }
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.register_msg_error), Toast.LENGTH_SHORT).show();
        }
    }
}
