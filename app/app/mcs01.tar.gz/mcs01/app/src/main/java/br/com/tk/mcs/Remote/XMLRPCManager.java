package br.com.tk.mcs.Remote;

/**
 * Created by revolution on 28/01/16.
 */

import android.os.AsyncTask;
import android.util.Log;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import de.timroes.axmlrpc.XMLRPCClient;
import de.timroes.axmlrpc.XMLRPCException;

public class XMLRPCManager extends AsyncTask<XMLRPCInfo, Void, Object> {

    private XMLRPCClient client = null;
    private int timeout = 300;

    public XMLRPCManager(String url, int timeout) throws MalformedURLException {
        if (client == null) {
            client = new XMLRPCClient(new URL(url), XMLRPCClient.FLAGS_DEFAULT_TYPE_STRING);
        }
        this.timeout = timeout;
    }

    @Override
    protected Object doInBackground(XMLRPCInfo... params) {
        Object     res  = null;
        XMLRPCInfo info = params[0];

        if (timeout != 0)
            client.setTimeout(timeout);

        switch ( info.getMethod() ) {

            case userRequest:
            case tagPlateRequest:
                try {
                    res = client.call( info.getMethod().name(), ( String[] ) info.getValues() );
                } catch (XMLRPCException e) {
                    e.printStackTrace();
                }
                break;

            case getShortStatus:
            case getLongStatus:
            case isRemotePaymentPermitted:
                try {
                    res = client.call( info.getMethod().name() );
                } catch (XMLRPCException e) {
                    e.printStackTrace();
                }
                break;

            case paymentRD:
            case remotePayment:
                try {
                    res = client.call( info.getMethod().name(), ( Object[] ) info.getValues() );
                } catch (XMLRPCException e) {
                    e.printStackTrace();
                }
                break;

            case operationRequest:
                try {
                    res = client.call( info.getMethod().name(), ( HashMap ) info.getValues() );
                } catch (XMLRPCException e) {
                    e.printStackTrace();
                }
                break;

            default:
                break;
        }
        return res;
    }
}