package br.com.tk.mcs.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by revolution on 31/01/16.
 */

public class Persistence extends SQLiteOpenHelper {

    public static final String database = "database.db";
    public static final String lane     = "lane";
    public static final String conf     = "conf";
    public static final String id       = "_id";
    public static final String name     = "name";
    public static final String ip       = "ip";
    public static final String sen      = "sentido";
    public static final int    version   = 23;

    public Persistence(Context context) {
        super(context, database, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + lane + " ("
                + id + " integer primary key autoincrement, "
                + ip + " text NOT NULL UNIQUE, "
                + name + " text NOT NULL UNIQUE, "
                + sen + " text NOT NULL);";
        Log.d(this.getClass().getName(), sql.toString());
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + lane);
        onCreate(db);
    }
}
