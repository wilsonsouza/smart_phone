package br.com.tk.mcs.Remote;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by revolution on 02/02/16.
 */

public class XMLRPCInfo {

    public enum XMLRPCMethods {
        getShortStatus, getLongStatus, operationRequest, tablesRequest, alarmsRequest, paramRequest, setParam, isRemotePaymentPermitted,
        remotePayment, changeClass, userRequest, fareRequest, tagPlateRequest, remoteRDPayment, paymentRD;
    }

    private XMLRPCMethods method;
    private Object values;

    public XMLRPCInfo(XMLRPCMethods method) {
        setMethod( method );
    }

    public XMLRPCInfo(XMLRPCMethods method, ArrayList<String> values) {
        setMethod( method );
        setValues(values);
    }

    public XMLRPCInfo(XMLRPCMethods method, Object[] values) {
        setMethod( method );
        setValues( values );
    }

    public XMLRPCInfo(XMLRPCMethods method, String[] values) {
        setMethod( method );
        setValues( values );
    }

    public XMLRPCInfo(XMLRPCMethods method, Map<String, Object> values) {
        setMethod( method );
        setValues( values );
    }

    XMLRPCMethods getMethod() {
        return method;
    }

    void setMethod(XMLRPCMethods method) {
        this.method = method;
    }

    Object getValues() {
        return values;
    }

    void setValues(Object values) {
        this.values = values;
    }
}