package br.com.tk.mcs.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Space;

import java.util.ArrayList;
import br.com.tk.mcs.Generic.AlertDialogBuilder;
import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.Lane.Lane;
import br.com.tk.mcs.Lane.State.BarreraState;
import br.com.tk.mcs.Lane.State.LaneState;
import br.com.tk.mcs.Lane.State.TrafficLightState;
import br.com.tk.mcs.R;
import br.com.tk.mcs.Remote.Response.GetLongStatusResponse;
import br.com.tk.mcs.Remote.Response.RemotePaymentPermittedResponse;
import br.com.tk.mcs.Remote.Response.RemotePaymentResponse;
import br.com.tk.mcs.Remote.Response.TagPlateResponse;

public class ManagerActivity extends AppCompatActivity {
    private String m_operator;
    private LaneState m_state;
    private ProgressDialog m_dialog = null;
    private boolean m_active = false, m_trocarOpeador = false;
    private int atual = 0, proximo = 0;
    private ArrayList<Lane> lanes;
    private final Handler handler = new Handler();
    private Button btTag, btOpen, btClose, btResponsable, btPayMoney, btPayTag;

    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            m_active = true;
            while (m_active) {
                final Lane lane = lanes.get(atual);
                final GetLongStatusResponse res = lane.getOperations().getLongStatus();

                if (atual != proximo) {
                    setState(null, lane, true);
                    atual = proximo;
                } else {
                    setState(res, lane, false);
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    private OnClickListener lanesClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            final int checkedId = v.getId();
            if (ActivityLogic.getLaneByInterface(checkedId) != atual) {
                final Lane lane = lanes.get(atual);
                final int id = lane.getId();
                new AlertDialog.Builder(ManagerActivity.this)
                        .setTitle(getString(R.string.manager_lane_name))
                        .setMessage(getString(R.string.manager_lane_response))
                        .setCancelable(false)
                        .setPositiveButton(getString(R.string.manager_button_confirm),
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        RadioButton rd = null;
                                        rd = (RadioButton) findViewById(ActivityLogic.getLaneButtonId(id));

                                        if (ActivityLogic.getLaneButtonId(id) == checkedId)
                                            rd.setChecked(true);
                                        else {
                                            rd.setChecked(false);
                                            rd = (RadioButton) findViewById(checkedId);
                                            rd.setChecked(true);
                                            proximo = ActivityLogic.getLaneByInterface(checkedId);
                                            m_dialog = ProgressDialog.show(ManagerActivity.this, getString(R.string.manager_lane_name), getString(R.string.main_alert_login_sync), true, false);
                                        }
                                    }
                                }
                        )
                        .setNegativeButton(getString(R.string.manager_button_cancel),
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int whichButton) {
                                        RadioButton rd = (RadioButton) findViewById(checkedId);
                                        if (ActivityLogic.getLaneButtonId(id) == checkedId)
                                            rd.setChecked(true);
                                        else
                                            rd.setChecked(false);
                                    }
                                }
                        )
                        .create().show();
            }
        }
    };

    private OnClickListener marquiseShortCurt = new OnClickListener() {
        @Override
        public void onClick(View v) {
            mudarEstadoMarquise();
        }
    };

    private OnClickListener cancelaShortCurt = new OnClickListener() {
        @Override
        public void onClick(View v) {
            mudarEstadoCancela();
        }
    };

    private OnClickListener liberarShortCurt = new OnClickListener() {
        @Override
        public void onClick(View v) {
            liberarVeiculo();
        }
    };

    private OnClickListener operationsClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btTag:
                    consultarTag();
                    break;
                case R.id.btResponsable:
                    trocarOperador();
                    break;
                case R.id.btOpen:
                    abrirPista();
                    break;
                case R.id.btClose:
                    fecharPista();
                    break;
                case R.id.btPayMoney:
                    rdCash();
                    break;
                case R.id.btPayTag:
                    rdTag();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_exit_title), getString(R.string.manager_exit_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        m_active = false;
                        finish();
                    }
                });
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        lanes = (ArrayList<Lane>) getIntent().getSerializableExtra(Utils.LANE);
        m_operator = getIntent().getStringExtra(Utils.OPERATOR);
        setTitle(Utils.USER + m_operator);
        initialize();
    }

    public void initialize() {
        btTag = (Button) findViewById(R.id.btTag);
        btTag.setOnClickListener(operationsClick);

        btOpen = (Button) findViewById(R.id.btOpen);
        btOpen.setOnClickListener(operationsClick);

        btClose = (Button) findViewById(R.id.btClose);
        btClose.setOnClickListener(operationsClick);

        btResponsable = (Button) findViewById(R.id.btResponsable);
        btResponsable.setOnClickListener(operationsClick);

        btPayMoney = (Button) findViewById(R.id.btPayMoney);
        btPayMoney.setOnClickListener(operationsClick);

        btPayTag = (Button) findViewById(R.id.btPayTag);
        btPayTag.setOnClickListener(operationsClick);

        for (final Lane lane : lanes) {
            int id = lane.getId();
            LinearLayout layout = (LinearLayout) findViewById(ActivityLogic.getLayoutById(id));
            layout.setVisibility(View.VISIBLE);

            Space space = (Space) findViewById(ActivityLogic.getDivById(id));
            space.setVisibility(View.VISIBLE);

            RadioButton radioButton = (RadioButton) findViewById(ActivityLogic.getLaneButtonId(id));
            radioButton.setChecked(lane.getId() == atual);
            radioButton.setText(lane.getLaneName());
            radioButton.setOnClickListener(lanesClick);

            ImageButton imgButton = null;
            imgButton = (ImageButton) findViewById(ActivityLogic.getBarrerButtonById(id));
            imgButton.setOnClickListener(cancelaShortCurt);
            imgButton.setEnabled(false);

            imgButton = (ImageButton) findViewById(ActivityLogic.getLightButtonId(id));
            imgButton.setOnClickListener(marquiseShortCurt);
            imgButton.setEnabled(false);

            imgButton = (ImageButton) findViewById(ActivityLogic.getVehicleButtonId(id));
            imgButton.setOnClickListener(liberarShortCurt);
            imgButton.setEnabled(false);
        }
        new Thread(runnable).start();
    }

    private void consultarTag() {
        AlertDialogBuilder.inputAlert(this, getString(R.string.manager_tag_title), AlertDialogBuilder.TLayout.TAGPLATE, AlertDialogBuilder.TButtons.SEARCH_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                final Dialog dialog = (Dialog) dialogInterface;
                final EditText tagPlate = (EditText) dialog.findViewById(R.id.edtPlate);

                if (tagPlate.getText().toString().length() != 7 && tagPlate.getText().toString().length() != 10) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_tag_field), TagPlateResponse.getText(ManagerActivity.this, TagPlateResponse.SizeError));
                    return;
                }

                final ProgressDialog progress = ProgressDialog.show(ManagerActivity.this, getString(R.string.manager_tag_title), getString(R.string.manager_tag_find), true, false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        TagPlateResponse res = TagPlateResponse.Error;
                        for (final Lane lane : lanes) {
                            try {
                                res = lane.getOperations().tagPlateRequest(tagPlate.getText().toString().trim());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (res != TagPlateResponse.Error)
                                break;
                        }

                        progress.dismiss();
                        final String display = TagPlateResponse.getText(ManagerActivity.this, res);
                        if (!display.isEmpty()) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_tag_field), display);
                                }
                            });
                        }
                    }
                }).start();
            }
        });
    }

    private void abrirPista() {
        AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_open_title), getString(R.string.manager_open_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                btOpen.setEnabled(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean res;
                        try {
                            res = lanes.get(atual).getOperations().setLaneON();
                        } catch (Exception e) {
                            res = false;
                        }

                        final boolean display = res;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!display) {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_open_title), getString(R.string.manager_response_error));
                                    if (m_state != LaneState.NoSync && m_state != LaneState.Starting)
                                        btOpen.setEnabled(true);
                                }
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void fecharPista() {
        AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_close_title), getString(R.string.manager_close_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                btClose.setEnabled(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean res;
                        try {
                            res = lanes.get(atual).getOperations().setLaneOFF();
                        } catch (Exception e) {
                            res = false;
                        }

                        final boolean display = res;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!display) {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_close_title), getString(R.string.manager_response_error));
                                    if ( m_state != LaneState.NoSync && m_state != LaneState.Starting )
                                        btClose.setEnabled(true);
                                }
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void trocarOperador() {
        AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_resp_title), getString(R.string.manager_resp_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                btResponsable.setEnabled(false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean res;
                        try {
                            res = lanes.get(atual).getOperations().setLaneOperator();
                        } catch (Exception e) {
                            res = false;
                        }

                        final boolean display = res;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!display) {;
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_resp_title), getString(R.string.manager_response_error));
                                    if ( m_state != LaneState.NoSync && m_state != LaneState.Starting )
                                        btResponsable.setEnabled(true);
                                } else {
                                    m_trocarOpeador = true;
                                }
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void mudarEstadoMarquise() {
        final Lane lane = lanes.get(atual);
        final TrafficLightState state = lane.getMarquiseState();
        AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_marq_title), getString(R.string.manager_marq_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean res;
                        try {;
                            if (state == TrafficLightState.LightGreen)
                                res = lane.getOperations().setTrafficLightOFF();
                            else if (state == TrafficLightState.LightOff)
                                res = lane.getOperations().setTrafficLightON();
                            else
                                res = false;
                        } catch (Exception e) {
                            res = false;
                        }

                        final boolean display = res;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!display)
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_marq_title), getString(R.string.manager_response_error));
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void mudarEstadoCancela() {
        final Lane lane = lanes.get(atual);
        final BarreraState state = lane.getBarreraState();
        AlertDialogBuilder.decisionAlert(ManagerActivity.this, getString(R.string.manager_marq_title), (state != BarreraState.SensorON) ?
                getString(R.string.manager_barrera_close_response) : getString(R.string.manager_barrera_open_response), AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean res;
                        try {
                            if (state == BarreraState.SensorON)
                                res = lane.getOperations().setBarrierOFF();
                            else if (state == BarreraState.SensorOFF)
                                res = lane.getOperations().setBarrierON();
                            else
                                res = false;
                        } catch (Exception e) {
                            res = false;
                        }

                        final boolean display = res;
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (!display)
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_marq_title), getString(R.string.manager_response_error));
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void liberarVeiculo() {
        AlertDialogBuilder.inputAlert(this, getString(R.string.manager_assign_title), AlertDialogBuilder.TLayout.TAGPLATE, AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                final Dialog dialog = (Dialog) dialogInterface;
                final EditText tagPlate = (EditText) dialog.findViewById(R.id.edtPlate);

                if (tagPlate.getText().toString().length() != 7 && tagPlate.getText().toString().length() != 10) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_tag_field), TagPlateResponse.getText(ManagerActivity.this, TagPlateResponse.SizeError));
                    return;
                }

                final ProgressDialog progress = ProgressDialog.show(ManagerActivity.this, getString(R.string.manager_assign_title), getString(R.string.manager_assign_process), true, false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        RemotePaymentResponse res = RemotePaymentResponse.ResponseERROR;
                        try {
                            final Lane lane = lanes.get(atual);
                            RemotePaymentPermittedResponse payment = lane.getOperations().isRemotePaymentPermitted();
                            res = lane.getOperations().remotePayment(payment, tagPlate.getText().toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        progress.dismiss();
                        final RemotePaymentResponse display = res;
                        if (display != RemotePaymentResponse.ResponseOK) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_assign_title), RemotePaymentResponse.getText(ManagerActivity.this, display));
                                }
                            });
                        }
                    }
                }).start();
            }
        });
    }

    private void rdCash() {
        AlertDialogBuilder.inputAlert(this, getString(R.string.manager_rdmoney_title), AlertDialogBuilder.TLayout.RDMONEY, AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                final Dialog dialog = (Dialog) dialogInterface;
                final EditText recipt = (EditText) dialog.findViewById(R.id.edtRecipt);
                final EditText cat = (EditText) dialog.findViewById(R.id.edtCat);

                if (recipt.getText().toString().length() != 12) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdmoney_title), getString(R.string.manager_recipt_tokensize));
                    return;
                }

                if ( cat.getText().toString().isEmpty() ) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdmoney_title), getString(R.string.manager_cat_tokensize));
                    return;
                }

                final ProgressDialog progress = ProgressDialog.show(ManagerActivity.this, getString(R.string.manager_rdmoney_title), getString(R.string.manager_assign_process), true, false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        RemotePaymentResponse res = RemotePaymentResponse.ResponseERROR;
                        try {
                            res = lanes.get(atual).getOperations().paymentRDCash(recipt.getText().toString().toUpperCase(), cat.getText().toString().toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        progress.dismiss();
                        final RemotePaymentResponse display = res;
                        if (display != RemotePaymentResponse.ResponseOK) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdmoney_title), RemotePaymentResponse.getText(ManagerActivity.this, display));
                                }
                            });
                        }
                    }
                }).start();
            }
        });
    }

    private void rdTag() {
        AlertDialogBuilder.inputAlert(this, getString(R.string.manager_rdtag_title), AlertDialogBuilder.TLayout.RDTAG, AlertDialogBuilder.TButtons.CONFIRM_AND_CANCEL, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                final Dialog dialog = (Dialog) dialogInterface;
                final EditText recipt = (EditText) dialog.findViewById(R.id.edtRecipt);
                final EditText tagPlate = (EditText) dialog.findViewById(R.id.edtTagPlate);

                if ( recipt.getText().toString().length() != 12 ) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdmoney_title), getString(R.string.manager_recipt_tokensize));
                    return;
                }

                if ( tagPlate.getText().toString().length() != 7 && tagPlate.getText().toString().length() != 10 ) {
                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdmoney_title), getString(R.string.manager_plate_tokensize));
                    return;
                }

                final ProgressDialog progress = ProgressDialog.show(ManagerActivity.this, getString(R.string.manager_rdtag_title), getString(R.string.manager_assign_process), true, false);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        RemotePaymentResponse res = RemotePaymentResponse.ResponseERROR;
                        try {
                            res = lanes.get(atual).getOperations().paymentRDTag(recipt.getText().toString().toUpperCase(), tagPlate.getText().toString().toUpperCase());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        progress.dismiss();
                        final RemotePaymentResponse display = res;
                        if (display != RemotePaymentResponse.ResponseOK) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    AlertDialogBuilder.messageAlert(ManagerActivity.this, getString(R.string.manager_rdtag_title), RemotePaymentResponse.getText(ManagerActivity.this, display));
                                }
                            });
                        }
                    }
                }).start();
            }
        });
    }

    private void setState(final GetLongStatusResponse res, final Lane lane, final boolean changes) {
        final int id = lane.getId();
        final int totalVehicles = (res != null ) ? res.getDevice().getTotalVehicles() : 0;
        final int stoppedVehicle = (res != null ) ? res.getDevice().getVehicleStopped() : 0;
        final LaneState state = (res != null ) ? LaneState.fromValue(res.getLaneState()) : (changes) ? LaneState.Starting : LaneState.NoSync;
        final BarreraState barreraState = (res != null ) ? BarreraState.fromValue(res.getDevice().getBarrierExit()) : (changes) ? BarreraState.SensorUnknown : (state == LaneState.NoSync) ?  BarreraState.SensorUnknown : BarreraState.SensorOFF;
        final TrafficLightState lightEntry = (res != null ) ? TrafficLightState.fromValue(res.getDevice().getLightStateEntry()) : (changes) ? TrafficLightState.LightUnkown : (state == LaneState.NoSync) ?  TrafficLightState.LightUnkown : TrafficLightState.LightOff;
        final TrafficLightState lightExit = (res != null ) ? TrafficLightState.fromValue(res.getDevice().getLightStateExit()) : (changes) ? TrafficLightState.LightUnkown : (state == LaneState.NoSync) ?  TrafficLightState.LightUnkown : TrafficLightState.LightOff;
        final String operator = (res != null) ? res.getOperatorCode() : null;
        final boolean eOperator = m_operator.equals(operator);
        m_state = state;

        handler.post(new Runnable() {
            @Override
            public void run() {
                Button button = null;
                ImageButton imgButton = null;
                RadioButton radioButton = null;

                if (state != lane.getLaneState() || m_trocarOpeador) {
                    radioButton = (RadioButton) findViewById(ActivityLogic.getLaneButtonId(id));
                    radioButton.setBackgroundColor(LaneState.getColor(state));
                    radioButton.setText(lane.getLaneName());

                    btTag.setEnabled(state != LaneState.NoSync && state != LaneState.Starting);
                    btOpen.setEnabled(state == LaneState.Closed);
                    btClose.setEnabled(state == LaneState.Opened && eOperator);
                    btResponsable.setEnabled(state == LaneState.Opened && !eOperator);
                    btPayMoney.setEnabled(state != LaneState.NoSync && state != LaneState.Starting && eOperator);
                    btPayTag.setEnabled(state != LaneState.NoSync && state != LaneState.Starting && eOperator);

                    imgButton = (ImageButton) findViewById(ActivityLogic.getLightButtonId(id));
                    imgButton.setEnabled(state == LaneState.Opened && eOperator);

                    imgButton = (ImageButton) findViewById(ActivityLogic.getBarrerButtonById(id));
                    imgButton.setEnabled(state == LaneState.Opened && eOperator);

                    lane.setLaneState(state);
                    m_trocarOpeador = false;
                }

                if ( state != lane.getLaneState() || totalVehicles != lane.getTotalVehicles() || stoppedVehicle != lane.getVehicleStopped() ) {
                    imgButton = (ImageButton) findViewById(ActivityLogic.getVehicleButtonId(id));
                    imgButton.setEnabled(state == LaneState.Opened && eOperator && stoppedVehicle == 1);
                    if (totalVehicles > 3)
                        imgButton.setImageResource(R.drawable.area4);
                    else if (totalVehicles == 3)
                        imgButton.setImageResource(R.drawable.area3);
                    else if (totalVehicles == 2)
                        imgButton.setImageResource(R.drawable.area2);
                    else if (totalVehicles == 1)
                        imgButton.setImageResource(R.drawable.area1);
                    else
                        imgButton.setImageResource(R.drawable.area_blank);

                    lane.setVehicleStopped(stoppedVehicle);
                    lane.setTotalVehicles(totalVehicles);
                }

                if ( lightEntry != lane.getMarquiseState() ) {
                    imgButton = (ImageButton) findViewById(ActivityLogic.getLightButtonId(id));
                    if (lightEntry == TrafficLightState.LightGreen)
                        imgButton.setImageResource(R.drawable.light_green);
                    else if (lightEntry == TrafficLightState.LightRed)
                        imgButton.setImageResource(R.drawable.light_red);
                    else if (lightEntry == TrafficLightState.LightUnkown)
                        imgButton.setImageResource(R.drawable.light_blank);
                    else
                        imgButton.setImageResource(R.drawable.light_error);

                    lane.setMarquiseState(lightEntry);
                }

                if ( lightExit != lane.getPassageState() ) {
                    imgButton = (ImageButton) findViewById(ActivityLogic.getTrafficButtonById(id));
                    if (lightExit == TrafficLightState.LightGreen)
                        imgButton.setImageResource(R.drawable.traffic_green);
                    else if (lightExit == TrafficLightState.LightRed)
                        imgButton.setImageResource(R.drawable.traffic_red);
                    else if (lightExit == TrafficLightState.LightUnkown)
                        imgButton.setImageResource(R.drawable.traffic_blank);
                    else
                        imgButton.setImageResource(R.drawable.traffic_error);

                    lane.setPassageState(lightExit);
                }

                if (barreraState != lane.getBarreraState() ) {
                    imgButton = (ImageButton) findViewById(ActivityLogic.getBarrerButtonById(id));
                    if (barreraState == BarreraState.SensorON)
                        imgButton.setImageResource(R.drawable.barrer_up);
                    else if (barreraState == BarreraState.SensorOFF)
                        imgButton.setImageResource(R.drawable.barrer_down);
                    else if (barreraState == BarreraState.SensorUnknown)
                        imgButton.setImageResource(R.drawable.barrer_blank);
                    else
                        imgButton.setImageResource(R.drawable.barrer_error);
                    lane.setBarreraState(barreraState);
                }

                if ( atual == proximo && state != LaneState.Starting ) {
                    if (m_dialog != null) {
                        m_dialog.dismiss();
                        m_dialog = null;
                    }
                }
            }
        });
    }
}
