package br.com.tk.mcs.Activity;

import android.app.ProgressDialog;
import android.content.Intent;;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.Lane.Lane;
import br.com.tk.mcs.Database.PersistenceController;
import br.com.tk.mcs.Lane.Operations;
import br.com.tk.mcs.R;
import br.com.tk.mcs.Remote.Response.UserRequestResponse;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView       imgLogo;
    private TextView        lbInfo;
    private Button          btLogin;
    private Button          btClear;
    private EditText        edtUser;
    private EditText        edtPass;
    private PersistenceController db;
    private final Handler handler = new Handler();

    private final TextWatcher watcher = new TextWatcher() {
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (edtUser.length() == 5 && edtPass.length() == 5) {
                Utils.hideSoftKeyboard(MainActivity.this);
                btLogin.setEnabled(true);
            } else {
                btLogin.setEnabled(false);
            }
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new PersistenceController(MainActivity.this);

        imgLogo  =  (ImageView) findViewById(R.id.imageView);
        imgLogo.setImageResource(R.drawable.logotamoios01);

        edtUser  =  (EditText) findViewById(R.id.edtUser);
        edtUser.getBackground().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
        edtUser.addTextChangedListener(watcher);

        edtPass  =  (EditText) findViewById(R.id.edtPass);
        edtPass.getBackground().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_ATOP);
        edtPass.addTextChangedListener(watcher);

        btLogin  =  (Button)   findViewById(R.id.btLogin);
        btLogin.setOnClickListener(this);

        btClear  =  (Button)   findViewById(R.id.btClear);
        btClear.setOnClickListener(this);
        btClear.setEnabled(true);

        lbInfo   =  (TextView) findViewById(R.id.lbInfo);
        lbInfo.setText(Utils.getVersion(MainActivity.this));

        Utils.hideSoftKeyboardOnCreate(MainActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        edtUser.getText().clear();
        edtPass.getText().clear();
        edtUser.requestFocus();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == btClear.getId()) {
            edtUser.requestFocus();
            edtUser.getText().clear();
            edtPass.getText().clear();
            Utils.hideSoftKeyboard(MainActivity.this);
        } else {
            if (edtUser.getText().toString().equals(Utils.ROOT) && edtPass.getText().toString().equals(Utils.ROOT)) {
                Intent it = new Intent(MainActivity.this, ConfigurationActivity.class);
                startActivity(it);
                return;
            }

            if (db.getLanesCount() == 0) {
                Toast.makeText(MainActivity.this, getString(R.string.main_alert_login_no_lane), Toast.LENGTH_LONG).show();
                return;
            }

            final ProgressDialog dialog = ProgressDialog.show(MainActivity.this, getString(R.string.main_login), getString(R.string.main_alert_login_sync), true, false);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int i = 0;
                        ArrayList<Lane> lanes = new ArrayList<Lane>();
                        UserRequestResponse res = UserRequestResponse.NoAuthorized;

                        for (final String name : db.getLanesNames()) {
                            Lane lane = new Lane(i++, name, edtUser.getText().toString(), new Operations("http://" + db.getLaneAddressByName(name) + ":8000/"));
                            //lane.setTimeOut(LOGIN_TIMEOUT);
                            lanes.add(lane);

                            if (res != UserRequestResponse.Authorized) {
                                res = lane.getOperations().userRequest(edtUser.getText().toString(), edtPass.getText().toString());
                            }
                        }

                        dialog.dismiss();
                        if (res != UserRequestResponse.Authorized) {
                            final String display = ((res == UserRequestResponse.NoAuthorized) ? getString(R.string.main_alert_login_error) : getString(R.string.main_alert_login_no_communication));
                            if (!display.isEmpty()) {
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MainActivity.this, display, Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                        } else {
                            Intent it = new Intent(MainActivity.this, ManagerActivity.class);
                            it.putExtra(Utils.LANE, lanes);
                            it.putExtra(Utils.OPERATOR, edtUser.getText().toString());
                            startActivity(it);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}