package br.com.tk.mcs.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import br.com.tk.mcs.Database.PersistenceController;
import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.R;

public class ConfigurationActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private String current;
    private MenuItem update;
    private MenuItem delete;
    private ListView view;
    private PersistenceController controller;
    private static final int LIMIT = 30;
    private static final String IP = "IP";

    @Override
    protected  void onResume() {
        super.onResume();
        if (delete != null && update != null)
            setEnable(false);

        if (view != null)
            view.setAdapter(controller.loadLane(this));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuration);
        controller = new PersistenceController(this);
        view = (ListView) findViewById(R.id.lstLane);
        view.setOnItemClickListener(this);
        view.setAdapter(controller.loadLane(this));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_config, menu);
        delete = menu.findItem(R.id.menu_config_delete);
        update = menu.findItem(R.id.menu_config_update);
        setEnable(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent it;
        switch(item.getItemId()){
            case R.id.menu_config_insert:
                if ( controller.getLanesCount() < LIMIT ) {
                    it = new Intent(ConfigurationActivity.this, RegisterLaneActivity.class);
                    startActivity(it);
                    setEnable(false);
                } else {
                    Toast.makeText(getApplicationContext(), getString(R.string.config_msg_error), Toast.LENGTH_SHORT).show();
                }
                return true;

            case R.id.menu_config_update:
                it = new Intent(ConfigurationActivity.this, RegisterLaneActivity.class);
                it.putExtra(IP, current.substring(0, current.length() - 30 ).trim());
                startActivity(it);
                setEnable(false);
                return true;

            case R.id.menu_config_delete:
                String ip = current.substring(0, current.length() - 30 ).trim();
                controller.deleteLane(ip, controller.getLaneNameByIP(ip));
                view.setAdapter(controller.loadLane(ConfigurationActivity.this));
                setEnable(false);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void setEnable(boolean status) {
        delete.setEnabled(status);
        update.setEnabled(status);
    }

    public void onItemClick(AdapterView parent, View v, int position, long id) {
        setEnable(true);
        current = (String) (view.getItemAtPosition(position));
    }
}

