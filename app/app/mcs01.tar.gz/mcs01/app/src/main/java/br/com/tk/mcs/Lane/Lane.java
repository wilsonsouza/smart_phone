package br.com.tk.mcs.Lane;

import java.io.Serializable;

import br.com.tk.mcs.Lane.State.BarreraState;
import br.com.tk.mcs.Lane.State.LaneState;
import br.com.tk.mcs.Lane.State.TrafficLightState;

/**
 * Created by revolution on 30/01/16.
 */

public class Lane implements Serializable {
    private int id;
    private String laneName;
    private LaneState laneState;
    private BarreraState barreraState;
    private TrafficLightState passageState;
    private TrafficLightState marquiseState;
    private int vehicleStopped;
    private int totalVehicles;
    private Operations operations;

    public Lane(int id, String name, String operator, Operations operations) {
        setId(id);
        setOperations(operations);
        setVehicleStopped(0);
        setTotalVehicles(0);
        setLaneState(LaneState.Starting);
        setBarreraState(BarreraState.SensorUnknown);
        setMarquiseState(TrafficLightState.LightUnkown);
        setPassageState(TrafficLightState.LightUnkown);
        setLaneName(name);
    }

    public int getTotalVehicles() {
        return totalVehicles;
    }

    public void setTotalVehicles(int totalVehicles) {
        this.totalVehicles = totalVehicles;
    }

    public int getVehicleStopped() {
        return vehicleStopped;
    }

    public void setVehicleStopped(int vehicleStopped) {
        this.vehicleStopped = vehicleStopped;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LaneState getLaneState() {
        return laneState;
    }

    public void setLaneState(LaneState laneState) {
        this.laneState = laneState;
    }

    public String getLaneName() {
        return laneName;
    }

    public void setLaneName(String laneName) {
        this.laneName = laneName;
    }

    public Operations getOperations() {
        return operations;
    }

    public void setOperations(Operations operations) {
        this.operations = operations;
    }

    public BarreraState getBarreraState() {
        return barreraState;
    }

    public void setBarreraState(BarreraState barreraState) {
        this.barreraState = barreraState;
    }

    public TrafficLightState getPassageState() {
        return passageState;
    }

    public void setPassageState(TrafficLightState passageState) {
        this.passageState = passageState;
    }

    public TrafficLightState getMarquiseState() {
        return marquiseState;
    }

    public void setMarquiseState(TrafficLightState marquiseState) {
        this.marquiseState = marquiseState;
    }

}
