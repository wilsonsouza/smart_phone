package br.com.tk.mcs.Remote.Response;

import android.content.Context;

import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.R;

/**
 * Created by revolution on 16/02/16.
 */

public enum RemotePaymentResponse {
    ResponseOK(0), ResponseERROR(1), ResponseNoAutoriz(2), ResponseCambioEstadoImp(3), ResponseSimulImp(4),
    ResponsePayInvalid(5), ResponseInvalidRemoteLaneType(6), ResponseNoVehicleInRemoteLane(7),ResponseTAGInvalid(10),
    ResponseTAGBlackList(11);

    private int value;

    private RemotePaymentResponse(int value) {
        this.value = value;
    }

    int value() {
        return value;
    }

    public static RemotePaymentResponse fromValue(int value) {
        for (RemotePaymentResponse my: RemotePaymentResponse.values()) {
            if (my.value == value) {
                return my;
            }
        }
        return ResponseERROR;
    }

    public static String getText(Context ctx, RemotePaymentResponse value) {

        switch (value) {
            case ResponseNoAutoriz:
                return ctx.getString(R.string.manager_assign_no_auth);
            case ResponsePayInvalid:
                return ctx.getString(R.string.manager_assign_tagplate);
            case ResponseNoVehicleInRemoteLane:
                return ctx.getString(R.string.manager_assign_gone);
            case ResponseTAGInvalid:
                return ctx.getString(R.string.manager_assign_tagplate);
            case ResponseTAGBlackList:
                return ctx.getString(R.string.manager_assign_blocked);
            default:
                return ctx.getString(R.string.manager_tag_response_error);
        }
    }
};

