package br.com.tk.mcs.Generic;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.tk.mcs.BuildConfig;
import br.com.tk.mcs.R;

/**
 * Created by revolution on 14/02/16.
 */
public class Utils {
    //public final int LOGIN_TIMEOUT = 5;
    //public static final int OPERARIONS_TIMEOUT = 10;
    public static final String ROOT = "99999";
    public static final String LANE = "LANE";
    public static final String OPERATOR = "OPERATOR";
    private static final SimpleDateFormat date = new SimpleDateFormat("HH:mm");
    public static final String USER = "Usuário: ";

    public static String getVersion(Context ctx) {
        return BuildConfig.VERSION_NAME;
    }

    public static void hideSoftKeyboardOnCreate(Activity activity) {
        activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public static void showSoftKeyboard(Activity activity, View view) {
        activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.showSoftInput(view, 0);
    }

    public static boolean isSoftKeyboardShowing(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        return inputMethodManager.isActive();
    }

    public static void getVibrate(Context ctx, int milliseconds) {
        Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        v.vibrate(milliseconds);
    }
}
