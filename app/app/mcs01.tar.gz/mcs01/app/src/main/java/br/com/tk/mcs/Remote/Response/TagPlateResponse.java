package br.com.tk.mcs.Remote.Response;

import android.content.Context;

import br.com.tk.mcs.Generic.TColor;
import br.com.tk.mcs.Generic.Utils;
import br.com.tk.mcs.R;

/**
 * Created by revolution on 04/02/16.
 */

public enum TagPlateResponse {
    Paid(1), Exempt(2), BlackList(3), NoRegister(4), Error(5), SizeError(6);

    private int value;

    private TagPlateResponse(int value) {
        this.value = value;
    }

    int value() {
        return value;
    }

    public static TagPlateResponse fromValue(int value) {
        for (TagPlateResponse my: TagPlateResponse.values()) {
            if (my.value == value) {
                return my;
            }
        }
        return Error;
    }

    public static String getText(Context ctx, TagPlateResponse value) {

        String text;

        switch (value) {
            case Paid:
                text = TColor.getText( TColor.Green, ctx.getString(R.string.manager_tag_response_paid) );
                break;
            case Exempt:
                text = TColor.getText( TColor.Green, ctx.getString(R.string.manager_tag_response_exempt) );
                break;
            case BlackList:
                text = TColor.getText( TColor.Red,  ctx.getString(R.string.manager_tag_response_blacklist) );
                break;
            case NoRegister:
                text = TColor.getText( TColor.Red, ctx.getString(R.string.manager_tag_response_noregister) );
                break;
            case SizeError:
                text = TColor.getText( TColor.Red, ctx.getString(R.string.manager_tag_response_size_error) );
                break;
            default:
                text = TColor.getText( TColor.Red, ctx.getString(R.string.manager_tag_response_error) );
                break;
        }
        return text;
    }
}
