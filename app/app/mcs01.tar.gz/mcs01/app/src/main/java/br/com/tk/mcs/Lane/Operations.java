package br.com.tk.mcs.Lane;

import android.util.Log;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import br.com.tk.mcs.Remote.Response.GetLongStatusResponse;
import br.com.tk.mcs.Remote.Response.GetShortStatusResponse;
import br.com.tk.mcs.Remote.Response.RemotePaymentPermittedResponse;
import br.com.tk.mcs.Remote.Response.RemotePaymentResponse;
import br.com.tk.mcs.Remote.Response.TagPlateResponse;
import br.com.tk.mcs.Remote.Response.UserRequestResponse;
import br.com.tk.mcs.Remote.XMLRPCInfo;
import br.com.tk.mcs.Remote.XMLRPCManager;

/**
 * Created by revolution on 12/02/16.
 */

public class Operations implements Serializable {

    private int timeout;
    private String url;
    private String operator;
    private final static String sPAYMENTTYPE_PAYMENT = "P";
    private final static String sPAYMENTMEANS_CASH = "CA";
    private final static String sPAYMENTMEANS_TAG = "TG";

    public enum Tasks {
        opChangeResponsable(0), opChangeState(1), opBarrierExit(2), eOperCambiarBarreraEntrada(3), opTrafficLightPurple(4), opTrafficLightGreen(5),
        eOperSimula(6), eOperResetSas(7), eOperPagoRemoto(8), eOperReclasificacion(9), eOperConfAlarmasLevel1(10), eOperResetPC(11),
        eOperCambiarBarrerasOversized(12), eOperCambiarSemaforoSalida(13), eOpercommutarCofre(14), eOperCambiarBarreraEscape(15),
        eOperCargaHoppers(16), eOperDevuelveCambio(17), eOperCambiaSentidoVia(18), eOperImprimirRecibo(21);

        private final int id;
        Tasks(int id) { this.id = id; }
        public int getValue() { return id; }
    }

    public Operations(String url) {
        this.url = url;
    }

    public void setTimeOut(int seconds) { this.timeout = seconds; }

    public GetLongStatusResponse getLongStatus() {
        GetLongStatusResponse res = null;
        try {
            Map<String, Object> map = (HashMap) new XMLRPCManager(url,timeout).execute( new XMLRPCInfo(XMLRPCInfo.XMLRPCMethods.getLongStatus) ).get();
            res = (map != null ) ? GetLongStatusResponse.toGetLongStatusResponse(map) : null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return res;
    }

    public GetShortStatusResponse getShortStatus() {
        GetShortStatusResponse res = null;
        try {
            Map<String, Object> map = (HashMap) new XMLRPCManager(url,timeout).execute( new XMLRPCInfo(XMLRPCInfo.XMLRPCMethods.getShortStatus) ).get();
            res = ( map != null ) ? GetShortStatusResponse.toGetShortStatusResponse(map) : null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return res;
    }

    public UserRequestResponse userRequest(final String user, final String pass) {
        Object[] obj = null;
        this.operator = user;
        try {
            obj = ( Object[] ) new XMLRPCManager(url,timeout).execute( new XMLRPCInfo( XMLRPCInfo.XMLRPCMethods.userRequest, new String[] { user, pass } ) ).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return ( obj != null ) ? UserRequestResponse.fromValue( (Integer) obj[0] ) : UserRequestResponse.Error;
    }

    public TagPlateResponse tagPlateRequest(final String tagPlate) {
        Object[] obj = null;
        try {
            obj = ( Object[] ) new XMLRPCManager(url,timeout).execute( new XMLRPCInfo( XMLRPCInfo.XMLRPCMethods.tagPlateRequest, new String[] { tagPlate } ) ).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return TagPlateResponse.fromValue( (Integer) obj[0] );
    }

    public Boolean setLaneON() {
        Object res = ( (HashMap) setTask(Tasks.opChangeState, operator, 2) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setLaneOFF() {
        Object res = ( (HashMap) setTask(Tasks.opChangeState, operator, 0) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setBarrierON() {
        Object res = ( (HashMap) setTask(Tasks.opBarrierExit, operator, 1) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setBarrierOFF() {
        Object res = ( (HashMap) setTask(Tasks.opBarrierExit, operator, 0) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setTrafficLightON() {
        Object res = ( (HashMap) setTask(Tasks.opTrafficLightGreen, operator) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setTrafficLightOFF() {
        Object res = ( (HashMap) setTask(Tasks.opTrafficLightPurple, operator) ).get("responseCode");
        return ( (Integer) res == 0 );
    }

    public  Boolean setLaneOperator() {
        Object res = ( (HashMap) setTask(Tasks.opChangeResponsable, operator) ).get("responseCode");
        return ( (Integer) res == 0 );
    }


    private Object setTask(Tasks task, String code, int param, String payment) {
        return setOperations(task, code, param, payment);
    }

    private Object setTask(Tasks task, String code, int param) {
        return setOperations(task, code, param, "");
    }

    private Object setTask(Tasks task, String code) {
        return setOperations(task, code, 0, "");
    }

    private Object setOperations(Tasks task, String code, int param, String payment) {
        Object res = null;
        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put( "operationCode", task.getValue() );
            map.put( "operatorCode",  code );
            map.put( "parameter_VAL", param );
            map.put( "payment_VAL",   payment );
            res = new XMLRPCManager(url,timeout).execute( new XMLRPCInfo( XMLRPCInfo.XMLRPCMethods.operationRequest, map ) ).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return res;
    }

    public RemotePaymentPermittedResponse isRemotePaymentPermitted() {
        RemotePaymentPermittedResponse res = null;
        try {
            Object obj = new XMLRPCManager(url,timeout).execute(new XMLRPCInfo(XMLRPCInfo.XMLRPCMethods.isRemotePaymentPermitted)).get();
            res = RemotePaymentPermittedResponse.toRemotePaymentPermittedResponse((HashMap) obj);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return res;
    }

    public RemotePaymentResponse remotePayment(RemotePaymentPermittedResponse remote, String tagPlate) {
        Map<String, Object> res = null;
        try {
            Object[] transaction = new Object[8];
            Map<String,Object> map = new HashMap<String,Object>();
            transaction[0] = operator;
            transaction[1] = "";
            transaction[4] = "P";
            transaction[5] = "TG";
            map.put("pan", ( tagPlate.length() > 7 ) ? tagPlate : "" );
            map.put("plate", ( tagPlate.length() == 7 ) ? tagPlate : "" );
            transaction[6] = map;
            transaction[3] = remote.getTransaction().getTransactionid();
            transaction[2] = remote.getTransaction().getVehicleClass();
            transaction[7] = remote.getTransaction().getProperties().getVehicleSubclass();
            res = (HashMap) new XMLRPCManager(url,timeout).execute(new XMLRPCInfo(XMLRPCInfo.XMLRPCMethods.remotePayment, transaction)).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return RemotePaymentResponse.fromValue( ( res != null ) ? (Integer) res.get("responseCode") : 1);
    }

    public RemotePaymentResponse paymentRDCash(String id, String vehicleClass) {
        return paymentRD(id, vehicleClass, "", sPAYMENTTYPE_PAYMENT, sPAYMENTMEANS_CASH);
    }

    public RemotePaymentResponse paymentRDTag(String id, String tagPlate) {
        return paymentRD(id, "", tagPlate, sPAYMENTTYPE_PAYMENT, sPAYMENTMEANS_TAG);
    }

    private RemotePaymentResponse paymentRD(String id, String vehicleClass, String tagPlate, String paymentType, String paymentMeans) {
        Object[] res = null;
        try {
            Object[] transaction = new Object[7];
            Map<String,Object> map = new HashMap<String,Object>();
            transaction[0] = operator;
            transaction[1] = "";
            transaction[4] = paymentType;
            transaction[5] = paymentMeans;
            map.put("pan", ( tagPlate.length() > 7 ) ? tagPlate : "" );
            map.put("plate", ( tagPlate.length() == 7 ) ? tagPlate : "" );
            transaction[6] = map;
            transaction[3] = id;
            transaction[2] = vehicleClass;
            res = (Object[]) new XMLRPCManager(url,timeout).execute(new XMLRPCInfo(XMLRPCInfo.XMLRPCMethods.paymentRD, transaction)).get();
            Log.d(this.getClass().getName(), Integer.toString( (Integer) res[0]));
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return RemotePaymentResponse.fromValue( ( res != null ) ? (Integer) res[0] : 1);
    }
}
